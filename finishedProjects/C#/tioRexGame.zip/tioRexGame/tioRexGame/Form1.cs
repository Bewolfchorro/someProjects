﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tioRexGame
{
    public partial class Form1 : Form
    {
        

        int jumpSpeed;
        int force = 12;
        int score = 0;
        int obstacleSpeed = 10;
        int lastScore = 0;
        int i = 2;
        int position;
        int nuclearPoints = 0;
        int x = 1;
        int xy = 0;

        bool isGameOver = false;
        bool jumping = false;
        bool canJump = true;
        bool canDie = true;
        bool godzillaMode = false;
        bool beaming = false;

        Random rand = new Random();
        public Form1()
        {
            InitializeComponent();

            gameReset();
        }

        private void gameTimer_Tick(object sender, EventArgs e)
        {
            jumpSettings();
            obstacleSettings();
            points();

            if (godzillaMode)
            {
                decreaseNuclearPoints();
            }
            if (nuclearPoints <= 0)
            {
                trexTransform();
            }
            
        }

        private void keyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space && !jumping && canJump && !godzillaMode)
            {
                jumping = true;
                canJump = false;
            }
            else if (e.KeyCode == Keys.Space && godzillaMode)
            {
                beam.Visible = true;
                beaming = true;
            }
        }

        private void keyUp(object sender, KeyEventArgs e)
        {
            if (jumping)
            {
                jumping = false;
            }
            else if (beaming)
            {
                beam.Visible = false;
                beaming = false;
            }

            if (e.KeyCode == Keys.R && isGameOver)
            {
                gameReset();
            }

            if (e.KeyCode == Keys.Enter && !godzillaMode && nuclearPoints >= 1 && !isGameOver)
            {
                godzzilaTransform();

            }
            else if (e.KeyCode == Keys.Enter && godzillaMode)
            {
                trexTransform();
            }
        }

        private void gameReset()
        {
            force = 15;
            jumpSpeed = 0;
            jumping = false;
            score = 0;
            nuclearPoints = 0;
            obstacleSpeed = 10;
            scoreBoard.Text = "Score: " + score;
            tRex.Image = Properties.Resources.running;  
            isGameOver = false;  
            tRex.Top = 280;
            x = 1;

            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "obstacle")
                {
                    position = this.ClientSize.Width + rand.Next(200, 400) + (x.Width * 10);
                    x.Left = position;
                }
            }

            

            plane.Left = 770;
            plane.Top = 79;

            gameOverTXT.Visible = false;
            gameTimer.Start();
        }

        private bool canTransform()
        {
            if (nuclearPoints >= 0)
            {
                return true;
            }
            return false;
        }

        private void decreaseNuclearPoints()
        {
            xy++;
            if (xy == 120)
            {
                xy = 0;
                nuclearPoints--;
            }
            
        }

        private void godzzilaTransform()
        {
            if (canTransform())
            {
            tRex.Visible = false;
            godzilla.Visible = true;
            canDie = false;
            godzillaMode = true;
            }
            else
            {
                trexTransform();
            }
        }

        private void trexTransform()
        {
            tRex.Visible = true;
            godzilla.Visible = false;
            canDie = true;
            godzillaMode = false;
            beam.Visible = false;
        }

        private void points()
        {
            if (score / 10 == i && lastScore != score)
            {
                lastScore = score;
                obstacleSpeed++;
                i = i + 2;
            }

            if (score / 10 == x)
            {
                x++;
                nuclearPoints++;
            }
            nukeLvl.Text = "NUKE LVL : " + nuclearPoints;
        }

        private void gameOver()
        {
            gameOverTXT.Visible = true;
            gameOverTXT.Text = "GAME OVER!! Press R to play again";
        }

        private void obstacleSettings()
        {
            int animalSpeed = obstacleSpeed / 10;

            foreach (Control x in this.Controls)
            {
                if (x is PictureBox && (string)x.Tag == "obstacle")
                {
                    x.Left -= obstacleSpeed;

                    if (!godzillaMode)
                    {
                        if (x.Left < -30)
                        {
                            x.Left = this.ClientSize.Width + rand.Next(200, 400) + (x.Width * 15);
                            score++;
                        }

                        if (tRex.Bounds.IntersectsWith(x.Bounds) && canDie)
                        {
                            gameTimer.Stop();
                            tRex.Image = Properties.Resources.dead;
                            gameOver();
                            isGameOver = true;
                        }
                        
                    }
                    else if (godzillaMode)
                    {
                        if (x.Left < 200)
                        {
                            x.Left = this.ClientSize.Width + rand.Next(200, 400) + (x.Width * 15);
                        }
                    }
                }
            }

            foreach (Control a in this.Controls)
            {
                if (a is PictureBox && (string)a.Tag == "animals")
                {
                    a.Left -= animalSpeed;

                    if (a.Left < -30)
                    {
                        a.Left = this.ClientSize.Width + rand.Next(200, 400) + (a.Width * 15);
                    }
                }
            }
        

            if (score >= 10)
            {

                plane.Left -= obstacleSpeed;

                if (!godzillaMode)
                {
                    if (plane.Left < -80)
                    {
                        plane.Left = this.ClientSize.Width + rand.Next(200, 400) + (plane.Width * 15);
                    }

                    if (tRex.Bounds.IntersectsWith(plane.Bounds) && canDie)
                    {
                        gameTimer.Stop();
                        tRex.Image = Properties.Resources.dead;
                        gameOver();
                        isGameOver = true;
                    }
                }
                else if (godzillaMode)
                {
                    if (plane.Left < 200)
                    {
                        plane.Left = this.ClientSize.Width + rand.Next(200, 400) + (plane.Width * 15);
                        score++;
                    }
                }
            }

        }

        private void jumpSettings()
        {
            tRex.Top += jumpSpeed;

            scoreBoard.Text = "Score: " + score;

            if (jumping && force < 0)
            {
                jumping = false;
            }

            if (jumping)
            {
                jumpSpeed = -13;
                force -= 1;
                ufoLaser.Visible = true;
            }
            else
            {
                jumpSpeed = 13;
                ufoLaser.Visible = false;
            }

            if (tRex.Top > 279 && !jumping)
            {
                force = 15;
                tRex.Top = 280;
                jumpSpeed = 0;
                canJump = true;
            }
        }


    }
}
