﻿namespace tioRexGame
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.scoreBoard = new System.Windows.Forms.Label();
            this.gameTimer = new System.Windows.Forms.Timer(this.components);
            this.nukeLvl = new System.Windows.Forms.Label();
            this.gameOverTXT = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.clouds3 = new System.Windows.Forms.PictureBox();
            this.clouds2 = new System.Windows.Forms.PictureBox();
            this.clouds1 = new System.Windows.Forms.PictureBox();
            this.tRex = new System.Windows.Forms.PictureBox();
            this.ufo = new System.Windows.Forms.PictureBox();
            this.beam = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.groundBox = new System.Windows.Forms.PictureBox();
            this.obstacle1 = new System.Windows.Forms.PictureBox();
            this.obstacle2 = new System.Windows.Forms.PictureBox();
            this.godzilla = new System.Windows.Forms.PictureBox();
            this.plane = new System.Windows.Forms.PictureBox();
            this.ufoLaser = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clouds3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clouds2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clouds1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tRex)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ufo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.beam)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groundBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.obstacle1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.obstacle2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.godzilla)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plane)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ufoLaser)).BeginInit();
            this.SuspendLayout();
            // 
            // scoreBoard
            // 
            this.scoreBoard.AutoSize = true;
            this.scoreBoard.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.scoreBoard.Location = new System.Drawing.Point(13, 13);
            this.scoreBoard.Name = "scoreBoard";
            this.scoreBoard.Size = new System.Drawing.Size(142, 23);
            this.scoreBoard.TabIndex = 8;
            this.scoreBoard.Text = "Score : 0000";
            // 
            // gameTimer
            // 
            this.gameTimer.Interval = 30;
            this.gameTimer.Tick += new System.EventHandler(this.gameTimer_Tick);
            // 
            // nukeLvl
            // 
            this.nukeLvl.AutoSize = true;
            this.nukeLvl.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nukeLvl.Location = new System.Drawing.Point(589, 13);
            this.nukeLvl.Name = "nukeLvl";
            this.nukeLvl.Size = new System.Drawing.Size(120, 23);
            this.nukeLvl.TabIndex = 12;
            this.nukeLvl.Text = "NUKE LVL :";
            // 
            // gameOverTXT
            // 
            this.gameOverTXT.AutoSize = true;
            this.gameOverTXT.Font = new System.Drawing.Font("LCD", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gameOverTXT.Location = new System.Drawing.Point(71, 132);
            this.gameOverTXT.Name = "gameOverTXT";
            this.gameOverTXT.Size = new System.Drawing.Size(123, 33);
            this.gameOverTXT.TabIndex = 20;
            this.gameOverTXT.Text = "label1";
            this.gameOverTXT.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.gameOverTXT.Visible = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::tioRexGame.Properties.Resources.lizard;
            this.pictureBox3.Location = new System.Drawing.Point(674, 413);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(54, 43);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 23;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Tag = "animals";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::tioRexGame.Properties.Resources.snakeGif;
            this.pictureBox1.Location = new System.Drawing.Point(238, 412);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 56);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 21;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Tag = "animals";
            // 
            // clouds3
            // 
            this.clouds3.Image = global::tioRexGame.Properties.Resources.clouds;
            this.clouds3.Location = new System.Drawing.Point(354, 267);
            this.clouds3.Name = "clouds3";
            this.clouds3.Size = new System.Drawing.Size(96, 84);
            this.clouds3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.clouds3.TabIndex = 19;
            this.clouds3.TabStop = false;
            // 
            // clouds2
            // 
            this.clouds2.Image = global::tioRexGame.Properties.Resources.clouds;
            this.clouds2.Location = new System.Drawing.Point(197, -98);
            this.clouds2.Name = "clouds2";
            this.clouds2.Size = new System.Drawing.Size(273, 194);
            this.clouds2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.clouds2.TabIndex = 18;
            this.clouds2.TabStop = false;
            // 
            // clouds1
            // 
            this.clouds1.Image = global::tioRexGame.Properties.Resources.clouds;
            this.clouds1.Location = new System.Drawing.Point(528, 172);
            this.clouds1.Name = "clouds1";
            this.clouds1.Size = new System.Drawing.Size(181, 123);
            this.clouds1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.clouds1.TabIndex = 17;
            this.clouds1.TabStop = false;
            // 
            // tRex
            // 
            this.tRex.BackColor = System.Drawing.Color.Transparent;
            this.tRex.Image = global::tioRexGame.Properties.Resources.running;
            this.tRex.Location = new System.Drawing.Point(71, 346);
            this.tRex.Name = "tRex";
            this.tRex.Size = new System.Drawing.Size(42, 54);
            this.tRex.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.tRex.TabIndex = 2;
            this.tRex.TabStop = false;
            // 
            // ufo
            // 
            this.ufo.BackColor = System.Drawing.Color.Transparent;
            this.ufo.Image = global::tioRexGame.Properties.Resources.ufo;
            this.ufo.Location = new System.Drawing.Point(50, 41);
            this.ufo.Name = "ufo";
            this.ufo.Size = new System.Drawing.Size(101, 38);
            this.ufo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ufo.TabIndex = 14;
            this.ufo.TabStop = false;
            // 
            // beam
            // 
            this.beam.Image = global::tioRexGame.Properties.Resources.beam;
            this.beam.Location = new System.Drawing.Point(344, 165);
            this.beam.Name = "beam";
            this.beam.Size = new System.Drawing.Size(82, 62);
            this.beam.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.beam.TabIndex = 13;
            this.beam.TabStop = false;
            this.beam.Visible = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::tioRexGame.Properties.Resources.groundV3;
            this.pictureBox4.Location = new System.Drawing.Point(0, 399);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(918, 180);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 5;
            this.pictureBox4.TabStop = false;
            // 
            // groundBox
            // 
            this.groundBox.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.groundBox.Location = new System.Drawing.Point(0, 400);
            this.groundBox.Name = "groundBox";
            this.groundBox.Size = new System.Drawing.Size(768, 52);
            this.groundBox.TabIndex = 4;
            this.groundBox.TabStop = false;
            this.groundBox.Visible = false;
            // 
            // obstacle1
            // 
            this.obstacle1.Image = global::tioRexGame.Properties.Resources.obstacle_1;
            this.obstacle1.Location = new System.Drawing.Point(492, 346);
            this.obstacle1.Name = "obstacle1";
            this.obstacle1.Size = new System.Drawing.Size(29, 54);
            this.obstacle1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.obstacle1.TabIndex = 6;
            this.obstacle1.TabStop = false;
            this.obstacle1.Tag = "obstacle";
            // 
            // obstacle2
            // 
            this.obstacle2.Image = global::tioRexGame.Properties.Resources.obstacle_2;
            this.obstacle2.Location = new System.Drawing.Point(619, 360);
            this.obstacle2.Name = "obstacle2";
            this.obstacle2.Size = new System.Drawing.Size(38, 40);
            this.obstacle2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.obstacle2.TabIndex = 7;
            this.obstacle2.TabStop = false;
            this.obstacle2.Tag = "obstacle";
            // 
            // godzilla
            // 
            this.godzilla.Image = global::tioRexGame.Properties.Resources.godZilla;
            this.godzilla.Location = new System.Drawing.Point(-1, 123);
            this.godzilla.Name = "godzilla";
            this.godzilla.Size = new System.Drawing.Size(349, 294);
            this.godzilla.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.godzilla.TabIndex = 3;
            this.godzilla.TabStop = false;
            this.godzilla.Visible = false;
            // 
            // plane
            // 
            this.plane.Image = global::tioRexGame.Properties.Resources.planeGif;
            this.plane.Location = new System.Drawing.Point(770, 79);
            this.plane.Name = "plane";
            this.plane.Size = new System.Drawing.Size(156, 82);
            this.plane.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.plane.TabIndex = 16;
            this.plane.TabStop = false;
            // 
            // ufoLaser
            // 
            this.ufoLaser.Image = global::tioRexGame.Properties.Resources.ufoLaser;
            this.ufoLaser.Location = new System.Drawing.Point(9, 69);
            this.ufoLaser.Name = "ufoLaser";
            this.ufoLaser.Size = new System.Drawing.Size(182, 282);
            this.ufoLaser.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ufoLaser.TabIndex = 15;
            this.ufoLaser.TabStop = false;
            this.ufoLaser.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(767, 450);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.gameOverTXT);
            this.Controls.Add(this.clouds3);
            this.Controls.Add(this.clouds2);
            this.Controls.Add(this.clouds1);
            this.Controls.Add(this.tRex);
            this.Controls.Add(this.ufo);
            this.Controls.Add(this.beam);
            this.Controls.Add(this.nukeLvl);
            this.Controls.Add(this.scoreBoard);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.groundBox);
            this.Controls.Add(this.obstacle1);
            this.Controls.Add(this.obstacle2);
            this.Controls.Add(this.godzilla);
            this.Controls.Add(this.plane);
            this.Controls.Add(this.ufoLaser);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Tag = "obstacle";
            this.Text = "Tio Rex THE GAME";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.keyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.keyUp);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clouds3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clouds2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clouds1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tRex)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ufo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.beam)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groundBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.obstacle1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.obstacle2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.godzilla)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plane)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ufoLaser)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox tRex;
        private System.Windows.Forms.PictureBox godzilla;
        private System.Windows.Forms.PictureBox groundBox;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox obstacle1;
        private System.Windows.Forms.PictureBox obstacle2;
        private System.Windows.Forms.Label scoreBoard;
        private System.Windows.Forms.Timer gameTimer;
        private System.Windows.Forms.Label nukeLvl;
        private System.Windows.Forms.PictureBox beam;
        private System.Windows.Forms.PictureBox ufo;
        private System.Windows.Forms.PictureBox ufoLaser;
        private System.Windows.Forms.PictureBox plane;
        private System.Windows.Forms.PictureBox clouds1;
        private System.Windows.Forms.PictureBox clouds2;
        private System.Windows.Forms.PictureBox clouds3;
        private System.Windows.Forms.Label gameOverTXT;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox3;
    }
}

