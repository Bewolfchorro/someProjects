PT

Este projeto consiste em um timer que vai indicar o tempo restante até uma X hora.
Tem funções que permite passar de uma string para formato temporal, a string pode estar formatada de qualquer maneira que vai sempre retornar o formato de data correto. 
Dentro dessas funções tem uma que elimina todos os caracteres não numéricos e outra que a cada 2 caracteres mete um ':' para formatar a hora corretamente.

EN
This project consists of a timer that will indicate the remaining time until X hour.
It has functions that allow you to switch from a string to a time format, the string can be formatted in any way and it will always return the correct date format.
Within these functions there is one that eliminates all non-numeric characters and another that inserts a ':' every 2 characters to format the time correctly.